﻿using PartyInvitations.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PartyInvitations.Controllers
{
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		[HttpGet]
		public ActionResult RsvpForm()
		{
			
			return View();

		}

		[HttpPost]
		public ActionResult RsvpForm(Responce Responce)
		{
			// to  do email a response to the organiser
			if(ModelState.IsValid)
				{
				return View("Thanks", Responce);
			}
			else
			{
				return View();
			}
			return View("Thanks", Responce);

		}



		public ActionResult About()
		{
			ViewBag.Message = "Your application description page.";

			return View();
		}

		public ActionResult Contact()
		{
			ViewBag.Message = "Your contact page.";

			return View();
		}
	}
}