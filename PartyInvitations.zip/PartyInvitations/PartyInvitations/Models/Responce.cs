﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PartyInvitations.Models
{
	public class Responce
	{

		[Required(ErrorMessage ="Please enter you're name")]
		public string Name { get; set; }

		[Required(ErrorMessage = "Please enter you're email")]
		[RegularExpression(".+\\@.+\\..+", ErrorMessage = "Please enter a valid email")]
		public string Email { get; set; }

		[Required(ErrorMessage = "Please enter you're Phone Number")]
		public string Phone { get; set; }

		[Required(ErrorMessage = "Please say whether you will attend")]
		public bool? WillAttend { get; set; }
	}
}